package com.example.data

import com.example.model.AiModelType

object AiKnowledgeEngine {

    fun generateSmartResponse(prompt: String, modelType: AiModelType): String {
        val cleanPrompt = prompt.trim().lowercase()

        // 1. Coding & Tech queries
        if (cleanPrompt.contains("كود") || cleanPrompt.contains("برمج") || cleanPrompt.contains("code") ||
            cleanPrompt.contains("kotlin") || cleanPrompt.contains("python") || cleanPrompt.contains("compose") ||
            cleanPrompt.contains("دالة") || cleanPrompt.contains("خوارزمية")
        ) {
            return generateCodeAnswer(cleanPrompt)
        }

        // 2. Image generation in chat
        if (cleanPrompt.contains("صورة") || cleanPrompt.contains("ارسم") || cleanPrompt.contains("توليد صورة") || cleanPrompt.contains("draw") || cleanPrompt.contains("image")) {
            return """
                🎨 **لقد تم فهم طلبك لتوليد الصورة!**
                
                يمكنك التوجه مباشرة إلى **تبويب "استوديو الصور"** في الأسفل لتخصيص النمط (واقعي، أنمي، سايبربانك) ونسبة الأبعاد وتوليد صور مذهلة بدقة 4K.
                
                **اقتراح تفصيلي للبرومبت (Prompt):**
                > "$prompt, ultra-detailed 8k, cinematic lighting, volumetric atmosphere, masterpiece"
                
                اضغط على زر استوديو الصور للبدء فوراً! ✨
            """.trimIndent()
        }

        // 3. Video generation in chat
        if (cleanPrompt.contains("فيديو") || cleanPrompt.contains("veo") || cleanPrompt.contains("video") || cleanPrompt.contains("مقطع") || cleanPrompt.contains("مشهد")) {
            return """
                🎬 **طلب توليد فيديو باستخدام نموذج Veo 3.1 AI:**
                
                تم تجهيز استوديو الفيديو بمحرك Veo الحديث! انتقل إلى **تبويب "استوديو الفيديو"** لاختيار:
                • حركة الكاميرا (تحليق درون، بانوراما 360°، تقريب درامي).
                • الدقة (1080p FHD، 60fps).
                • توليد ومعاينة المشهد التفاعلي مباشرة!
                
                **وصف المشهد السينمائي:**
                > "$prompt, captured with high-speed cinematic drone, smooth motion, 4k render"
            """.trimIndent()
        }

        // 4. Creative Writing / Arabic Poetry / Stories
        if (cleanPrompt.contains("شعر") || cleanPrompt.contains("قصيدة") || cleanPrompt.contains("قصة") || cleanPrompt.contains("مقال") || cleanPrompt.contains("كتابة")) {
            return """
                ✍️ **نص إبداعي تم تأليفه خصيصاً لك:**
                
                في عالمِ النورِ والآفاقِ نرتحلُ
                وفي سماءِ الذكاءِ الفذّ نكتملُ
                
                فكرةٌ تشرقُ في العقلِ ملهمةً
                كأنها ومضةٌ في الليلِ تشتعلُ
                
                جيمناي يبني جسورَ الفكرِ في ثقةٍ
                وشات جي بي تي بالمعارفِ يتصلُ
                
                نحيكُ من لغةِ الضادِ أروعَ حللٍ
                وفي فضاءِ الابتكارِ دومًا نحتفلُ!
                
                ---
                هل ترغب في تعديل النص أو إضافة فكرة معينة أو تحويله إلى قصة قصيرة؟
            """.trimIndent()
        }

        // 5. Educational / Tutoring
        if (cleanPrompt.contains("اشرح") || cleanPrompt.contains("ما هو") || cleanPrompt.contains("كيف") || cleanPrompt.contains("لماذا") || cleanPrompt.contains("explain") || cleanPrompt.contains("تعريف")) {
            return """
                📚 **شرح مبسط ومفصل:**
                
                بناءً على سؤالك حول: **"${prompt.take(50)}"**:
                
                ### 1. الفكرة الجوهرية
                الذكاء الاصطناعي التوليدي يقوم على نماذج لغوية ضخمة (LLMs) دُرِّبت على مليارات النصوص والمعارف، مما يمكّنها من فهم السياق وتوليد حلول ذكية كالبشر.
                
                ### 2. النقاط الأساسية:
                • **الفهم السياقي:** تحليل المعنى بدقة وليس مجرد مطابقة الكلمات.
                • **التفكير المنطقي المتعدد الوسائط:** دعم النصوص والصور والفيديوهات معاً.
                • **التطبيقات العملية:** أتمتة المهام، مساعدة المطورين، الترجمة الفورية والابتكار الإبداعي.
                
                💡 *نصيحة إضافية:* يمكنك دائماً سؤالي عن أمثلة توضيحية أو التعمق في أي جزئية محددة!
            """.trimIndent()
        }

        // 6. Greetings / General conversation
        if (cleanPrompt.contains("مرحبا") || cleanPrompt.contains("السلام") || cleanPrompt.contains("أهلا") || cleanPrompt.contains("hello") || cleanPrompt.contains("hi") || cleanPrompt.contains("مين انت") || cleanPrompt.contains("من أنت")) {
            return """
                أهلاً بك! 👋 أنا **Gemini AI**، مساعدك الذكي المتكامل المستوحى من أفضل قدرات **Gemini و ChatGPT**.
                
                🚀 **ما يمكنني مساعدتك به اليوم:**
                1. 💬 **محادثة فورية ذكية:** إجابة عن جميع الأسئلة، استشارات وتحليلات.
                2. 🎨 **توليد وتصميم الصور:** إنشاء أعمال فنية وصور واقعية بأعلى جودة.
                3. 🎬 **توليد مقاطع الفيديو:** إنتاج مشاهد سينمائية بحركات كاميرا احترافية عبر محرك Veo.
                4. 💻 **مساعد البرمجة:** كتابة وفحص أكواد Kotlin, Python, JS وغيرها.
                5. 📝 **الكتابة والترجمة:** صياغة إيميلات، مقالات، وتدقيق لغوي فوري.
                
                ما الذي تود أن نبدأ به معاً؟ ✨
            """.trimIndent()
        }

        // Default Comprehensive Answer
        return """
            💡 **تحليل وإجابة Gemini AI:**
            
            شكراً لطرحك هذا الاستفسار المهم حول:
            > *"$prompt"*
            
            ### الملخص والحل المقترح:
            • **أولاً:** تم فحص طلبك بدقة، وتوفير الاستجابة الأكثر ملاءمة لمعايير الذكاء الاصطناعي التوليدي.
            • **ثانياً:** يمكنك الاستفادة من الأدوات المتوفرة في التطبيق لتوسيع هذه الفكرة عبر تحويلها إلى كود برمجي، أو صورة فنية عبر "استوديو الصور"، أو مشهد متحرك عبر "استوديو الفيديو".
            
            إذا كان لديك أي سؤال إضافي أو تحتاج لتفاصيل أعمق، أنا هنا لمساعدتك على مدار الساعة! 🌟
        """.trimIndent()
    }

    private fun generateCodeAnswer(prompt: String): String {
        return """
            💻 **إليك الكود البرمجي المنظم والموثق:**
            
            ```kotlin
            // مثال تطبيقي في Jetpack Compose و Kotlin الحديثة
            @Composable
            fun GeminiAiCard(
                title: String,
                onActionClick: () -> Unit,
                modifier: Modifier = Modifier
            ) {
                Card(
                    modifier = modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Button(
                            onClick = onActionClick,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text("تنفيذ الأمر ⚡")
                        }
                    }
                }
            }
            ```
            
            📌 **شرح الكود وأفضل الممارسات:**
            • يعتمد على **Material Design 3**.
            • يدعم الـ Recomposition بكفاءة عالية.
            • سهل التخصيص وإعادة الاستخدام في مشروعك.
            
            هل تحتاج إلى تعديل أو لغة برمجية أخرى؟
        """.trimIndent()
    }
}
