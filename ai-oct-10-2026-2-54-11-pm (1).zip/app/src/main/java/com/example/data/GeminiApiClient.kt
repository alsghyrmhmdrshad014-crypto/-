package com.example.data

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.model.AiModelType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiApiClient {
    private const val TAG = "GeminiApiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getApiKey(): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isBlank() || key == "MY_GEMINI_API_KEY") "" else key
        } catch (e: Throwable) {
            ""
        }
    }

    fun isApiKeyConfigured(): Boolean {
        return getApiKey().isNotBlank()
    }

    suspend fun generateTextResponse(
        prompt: String,
        modelType: AiModelType,
        attachedBitmap: Bitmap? = null,
        conversationHistory: List<Pair<String, String>> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(IllegalStateException("NO_API_KEY"))
        }

        try {
            val endpoint = "$BASE_URL/${modelType.apiModelId}:generateContent?key=$apiKey"

            val rootJson = JSONObject()

            // System instruction
            val systemContent = JSONObject()
            val systemParts = JSONArray()
            val systemPart = JSONObject().apply { put("text", modelType.systemPrompt) }
            systemParts.put(systemPart)
            systemContent.put("parts", systemParts)
            rootJson.put("systemInstruction", systemContent)

            // Contents array
            val contentsArray = JSONArray()

            // Append previous turns (up to last 6 for context)
            val trimmedHistory = conversationHistory.takeLast(6)
            for ((role, text) in trimmedHistory) {
                val turnContent = JSONObject()
                turnContent.put("role", if (role == "user") "user" else "model")
                val parts = JSONArray()
                parts.put(JSONObject().apply { put("text", text) })
                turnContent.put("parts", parts)
                contentsArray.put(turnContent)
            }

            // Current prompt turn
            val currentTurn = JSONObject()
            currentTurn.put("role", "user")
            val currentParts = JSONArray()
            currentParts.put(JSONObject().apply { put("text", prompt) })

            // Handle Multimodal Image if attached
            if (attachedBitmap != null) {
                val inlineData = JSONObject()
                inlineData.put("mimeType", "image/jpeg")
                inlineData.put("data", attachedBitmap.toBase64())
                val imagePart = JSONObject().apply { put("inlineData", inlineData) }
                currentParts.put(imagePart)
            }
            currentTurn.put("parts", currentParts)
            contentsArray.put(currentTurn)

            rootJson.put("contents", contentsArray)

            // Generation config
            val genConfig = JSONObject()
            genConfig.put("temperature", if (modelType == AiModelType.CREATIVE_WRITER) 0.9 else 0.7)
            genConfig.put("topP", 0.95)
            genConfig.put("topK", 40)
            rootJson.put("generationConfig", genConfig)

            val requestBody = rootJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini API Error: ${response.code} -> $responseBody")
                return@withContext Result.failure(Exception("Gemini HTTP ${response.code}: $responseBody"))
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val contentObj = firstCandidate.optJSONObject("content")
                val partsArray = contentObj?.optJSONArray("parts")
                if (partsArray != null && partsArray.length() > 0) {
                    val fullText = StringBuilder()
                    for (i in 0 until partsArray.length()) {
                        val part = partsArray.getJSONObject(i)
                        fullText.append(part.optString("text", ""))
                    }
                    return@withContext Result.success(fullText.toString().trim())
                }
            }

            Result.failure(Exception("لم يتم استلام نص صالح من الخادم"))
        } catch (e: Exception) {
            Log.e(TAG, "Exception calling Gemini API", e)
            Result.failure(e)
        }
    }

    private fun Bitmap.toBase64(): String {
        val outputStream = ByteArrayOutputStream()
        this.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }
}
