package com.example.data

import com.example.model.AiModelType
import com.example.model.PromptIdea

object PromptPresets {
    val starterPrompts: List<PromptIdea> = listOf(
        PromptIdea(
            id = "code_compose",
            categoryArabic = "برمجة وكود",
            titleArabic = "إنشاء شاشة Compose تفاعلية",
            promptArabic = "اكتب لي كود شاشة Jetpack Compose متكاملة تعرض قائمة بطاقات عصرية مع حركات انسيابية وزر إجراء عائم FAB.",
            iconEmoji = "💻",
            suggestedModel = AiModelType.CODE_MASTER
        ),
        PromptIdea(
            id = "creative_story",
            categoryArabic = "إبداع وقصص",
            titleArabic = "قصة خيال علمي في المستقبل",
            promptArabic = "اكتب قصة قصيرة مشوقة عن رحلة استكشافية إلى كوكب مكتشف حديثاً في مجرة أندروميدا عام 2150.",
            iconEmoji = "🚀",
            suggestedModel = AiModelType.CREATIVE_WRITER
        ),
        PromptIdea(
            id = "image_concept",
            categoryArabic = "توليد صور",
            titleArabic = "تصميم مدينة عربية مستقبلية",
            promptArabic = "ارسم لي صورة تخيلية لمدينة عربية في المستقبل المشرق تجمع بين العمارة التراثية والتقنيات الهولوغرافية والحدائق المعلقة.",
            iconEmoji = "🎨",
            suggestedModel = AiModelType.GEMINI_FLASH_3_5
        ),
        PromptIdea(
            id = "business_plan",
            categoryArabic = "أعمال واستراتيجية",
            titleArabic = "خطة إطلاق تطبيق هاتف ذكي",
            promptArabic = "ضع لي خطة تسويقية وعملية من 5 مراحل لإطلاق تطبيق جديد في السوق العربي مع قياس مؤشرات النجاح KPIs.",
            iconEmoji = "📈",
            suggestedModel = AiModelType.GEMINI_PRO_3_1
        ),
        PromptIdea(
            id = "video_concept",
            categoryArabic = "توليد فيديو",
            titleArabic = "مشهد درون سينمائي فوق واحة",
            promptArabic = "مشهد فيديو سينمائي كاميرا درون تحلق بسرعة فوق واحة متلألئة بين كثبان رملية ذهبية عند غروب الشمس.",
            iconEmoji = "🎬",
            suggestedModel = AiModelType.GEMINI_FLASH_3_5
        ),
        PromptIdea(
            id = "study_physics",
            categoryArabic = "تعليم ودراسة",
            titleArabic = "شرح فيزياء الكم ببساطة",
            promptArabic = "اشرح لي مبدأ التشابك الكمي (Quantum Entanglement) بأسلوب مبسط جداً وكأنني طالب في المرحلة الثانوية.",
            iconEmoji = "⚛️",
            suggestedModel = AiModelType.STUDY_TUTOR
        )
    )

    val categories: List<String> = listOf(
        "الكل",
        "برمجة وكود",
        "إبداع وقصص",
        "توليد صور",
        "توليد فيديو",
        "أعمال واستراتيجية",
        "تعليم ودراسة"
    )
}
