package com.example.data.local

import com.example.data.local.dao.ChatDao
import com.example.data.local.entities.ChatMessageEntity
import com.example.data.local.entities.ChatSessionEntity
import com.example.model.AiModelType
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ChatRepository(private val chatDao: ChatDao) {

    fun getAllSessions(): Flow<List<ChatSession>> {
        return chatDao.getAllSessions().map { entities ->
            entities.map { entity ->
                val modelType = try {
                    AiModelType.valueOf(entity.modelType)
                } catch (e: Exception) {
                    AiModelType.GEMINI_FLASH_3_5
                }
                ChatSession(
                    id = entity.id,
                    title = entity.title,
                    createdAt = entity.createdAt,
                    modelType = modelType
                )
            }
        }
    }

    fun getMessagesForSession(sessionId: String): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForSession(sessionId).map { entities ->
            entities.map { entity ->
                ChatMessage(
                    id = entity.id,
                    role = if (entity.role == "USER") MessageRole.USER else MessageRole.ASSISTANT,
                    text = entity.text,
                    timestamp = entity.timestamp,
                    modelName = entity.modelName,
                    isLiked = entity.isLiked
                )
            }
        }
    }

    suspend fun getMessagesForSessionSync(sessionId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        chatDao.getMessagesForSessionSync(sessionId).map { entity ->
            ChatMessage(
                id = entity.id,
                role = if (entity.role == "USER") MessageRole.USER else MessageRole.ASSISTANT,
                text = entity.text,
                timestamp = entity.timestamp,
                modelName = entity.modelName,
                isLiked = entity.isLiked
            )
        }
    }

    suspend fun insertSession(session: ChatSession) = withContext(Dispatchers.IO) {
        chatDao.insertSession(
            ChatSessionEntity(
                id = session.id,
                title = session.title,
                modelType = session.modelType.name,
                createdAt = session.createdAt,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun updateSessionTitle(sessionId: String, title: String) = withContext(Dispatchers.IO) {
        chatDao.updateSessionTitle(sessionId, title, System.currentTimeMillis())
    }

    suspend fun updateSessionModel(sessionId: String, modelType: AiModelType) = withContext(Dispatchers.IO) {
        chatDao.updateSessionModel(sessionId, modelType.name)
    }

    suspend fun deleteSession(sessionId: String) = withContext(Dispatchers.IO) {
        chatDao.deleteSession(sessionId)
    }

    suspend fun insertMessage(sessionId: String, message: ChatMessage) = withContext(Dispatchers.IO) {
        chatDao.insertMessage(
            ChatMessageEntity(
                id = message.id,
                sessionId = sessionId,
                role = if (message.role == MessageRole.USER) "USER" else "ASSISTANT",
                text = message.text,
                timestamp = message.timestamp,
                modelName = message.modelName,
                isLiked = message.isLiked
            )
        )
        // Also touch session's updatedAt timestamp
        chatDao.getSessionById(sessionId)?.let { session ->
            chatDao.updateSession(session.copy(updatedAt = System.currentTimeMillis()))
        }
    }

    suspend fun updateMessageLikeStatus(messageId: String, isLiked: Boolean?) = withContext(Dispatchers.IO) {
        chatDao.updateMessageLikeStatus(messageId, isLiked)
    }

    suspend fun ensureInitialWelcomeSession(): ChatSession = withContext(Dispatchers.IO) {
        val initialSession = ChatSession(
            title = "المحادثة الترحيبية الأولى",
            modelType = AiModelType.GEMINI_FLASH_3_5
        )
        insertSession(initialSession)

        val welcomeMsg = ChatMessage(
            role = MessageRole.ASSISTANT,
            text = """
                مرحباً بك في **Gemini AI**! ✨
                
                أنا مساعدك الذكي المتكامل المتقدم، مستوحى من أحدث تقنيات **Gemini و ChatGPT**.
                
                💾 **حفظ تلقائي للبيانات عبر Room:**
                جميع محادثاتك ورسائلك السابقة تُحفظ الآن بأمان محلياً في قاعدة بيانات SQLite عبر **Room Database** لتمكينك من العودة إليها وتصفحها في أي وقت!
                
                🚀 **الميزات المتاحة لك:**
                • 💬 **محادثة ذكية:** اسألني في البرمجة، العلوم، وتأليف النصوص وحل المشكلات.
                • 🎨 **استوديو الصور:** توليد صور فنية بدقة فائقة وبمختلف الأنماط ونسب الأبعاد.
                • 🎬 **استوديو الفيديو (Veo):** إنتاج مقاطع فيديو سينمائية مع محاكاة لحركات الكاميرا.
                • 🎙️ **دعم صوتي:** استمع لردودي فوراً بصوت واضح.
                
                اختر نموذجك المفضل، أو جرب أحد الاقتراحات السريعة أدناه للبدء!
            """.trimIndent(),
            modelName = "Gemini 3.5 Flash"
        )
        insertMessage(initialSession.id, welcomeMsg)
        initialSession
    }
}
