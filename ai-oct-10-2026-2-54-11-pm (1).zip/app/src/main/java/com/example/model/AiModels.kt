package com.example.model

import android.graphics.Bitmap

enum class MessageRole {
    USER,
    ASSISTANT,
    SYSTEM
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val role: MessageRole,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false,
    val attachedImage: Bitmap? = null,
    val generatedImageRes: Int? = null,
    val generatedVideoPrompt: String? = null,
    val modelName: String = "Gemini 3.5 Flash",
    val tokensUsed: Int = 0,
    val isLiked: Boolean? = null
)

data class ChatSession(
    val id: String = java.util.UUID.randomUUID().toString(),
    var title: String = "محادثة جديدة",
    val messages: MutableList<ChatMessage> = mutableListOf(),
    val createdAt: Long = System.currentTimeMillis(),
    var modelType: AiModelType = AiModelType.GEMINI_FLASH_3_5
)

enum class AiModelType(
    val id: String,
    val displayNameArabic: String,
    val displayNameEnglish: String,
    val descriptionArabic: String,
    val badge: String,
    val iconEmoji: String,
    val apiModelId: String,
    val systemPrompt: String
) {
    GEMINI_FLASH_3_5(
        id = "gemini-3.5-flash",
        displayNameArabic = "جيمناي 3.5 فلاش",
        displayNameEnglish = "Gemini 3.5 Flash",
        descriptionArabic = "فائق السرعة والدقة، ممتاز للأسئلة اليومية والترجمة والكتابة",
        badge = "الأسرع والأذكى",
        iconEmoji = "⚡",
        apiModelId = "gemini-3.5-flash",
        systemPrompt = "أنت مساعد ذكاء اصطناعي ودود وفائق الذكاء، تجيب باللغة العربية بطلاقة ودقة عالية، وتساعد المستخدم في شتى المجالات بأسلوب منظم وواضح."
    ),
    GEMINI_PRO_3_1(
        id = "gemini-3.1-pro-preview",
        displayNameArabic = "جيمناي 3.1 برو التفكيري",
        displayNameEnglish = "Gemini 3.1 Pro (Reasoning)",
        descriptionArabic = "تفكير عميق واستدلال متقدم للمسائل المعقدة والرياضيات والتحليل",
        badge = "تفكير متقدم",
        iconEmoji = "🧠",
        apiModelId = "gemini-3.1-pro-preview",
        systemPrompt = "أنت خبير التفكير العميق والاستدلال المنطقي. قم بتحليل المشكلات المعقدة خطوة بخطوة مع تقديم براهين وحلول دقيقة ومنهجية."
    ),
    CODE_MASTER(
        id = "gemini-code-expert",
        displayNameArabic = "خبير البرمجة وكود ماستر",
        displayNameEnglish = "Code Master Pro",
        descriptionArabic = "متخصص في كتابة وتصحيح أكواد Kotlin, Python, JS وشرح الخوارزميات",
        badge = "برمجة متقدمة",
        iconEmoji = "💻",
        apiModelId = "gemini-3.1-pro-preview",
        systemPrompt = "أنت كبير مهندسي البرمجيات. اكتب أكواد برمجية نظيفة وحديثة مع تعليقات وشرح دقيق، وقدم أفضل الممارسات وحلول الأخطاء."
    ),
    CREATIVE_WRITER(
        id = "gemini-creative",
        displayNameArabic = "الكاتب الإبداعي والمؤلف",
        displayNameEnglish = "Creative Writer",
        descriptionArabic = "صياغة مقالات، قصص ساحرة، أشعار عربية ومحتوى تسويقي جذاب",
        badge = "إبداع وخيال",
        iconEmoji = "✍️",
        apiModelId = "gemini-3.5-flash",
        systemPrompt = "أنت أديب وكاتب إبداعي بليغ. صُغ النصوص والقصص والمقالات بأسلوب عربي فصيح غني بالجماليات البلاغية والتشويق."
    ),
    STUDY_TUTOR(
        id = "gemini-tutor",
        displayNameArabic = "المعلم الذكي والشرح المبسط",
        displayNameEnglish = "AI Study Tutor",
        descriptionArabic = "شرح الدروس والفيزياء والتاريخ وتبسيط العلوم بأسلوب تفاعلي",
        badge = "تعليم ودراسة",
        iconEmoji = "🎓",
        apiModelId = "gemini-3.5-flash",
        systemPrompt = "أنت معلم متميز يشرح أصعب المفاهيم ببساطة وتدرج، مع ضرب أمثلة واقعية وأسئلة تفاعلية لترسيخ الفهم."
    )
}

enum class ImageAspectRatio(val label: String, val ratioWidth: Float, val ratioHeight: Float) {
    SQUARE("1:1 مربع", 1f, 1f),
    LANDSCAPE("16:9 عريض", 16f, 9f),
    PORTRAIT("9:16 طولي", 9f, 16f),
    PHOTO_LANDSCAPE("4:3 أفقي", 4f, 3f),
    PHOTO_PORTRAIT("3:4 عمودي", 3f, 4f)
}

enum class ImageArtStyle(val titleArabic: String, val promptModifier: String, val emoji: String) {
    PHOTOREALISTIC("واقعي فوتوغرافي", "photorealistic 8k, ultra-detailed shot, realistic studio lighting, Hasselblad photo", "📸"),
    CYBERPUNK("سايبربانك مستقبلي", "cyberpunk neon aesthetics, futuristic holographic lighting, vibrant contrast, detailed", "🏙️"),
    ANIME("أنمي وماكوتو شينكاي", "anime illustration style, vibrant Makoto Shinkai aesthetic, gorgeous colors, masterwork", "🌸"),
    FANTASY_ART("فن خيالي ملحمي", "epic digital fantasy art, magical glowing atmosphere, concept art, dynamic lighting", "🐉"),
    RENDER_3D("تصيير ثلاثي الأبعاد", "3D Pixar octane render style, soft ambient shadows, vibrant colorful playful textures", "🧊"),
    ARABIC_HERITAGE("تراث عربي أصيل", "rich Arabic oriental heritage, ornate Islamic geometry, golden ambient lights, exquisite details", "🕌")
}

data class GeneratedImageItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val prompt: String,
    val style: ImageArtStyle,
    val aspectRatio: ImageAspectRatio,
    val timestamp: Long = System.currentTimeMillis(),
    val localDrawableRes: Int? = null,
    val imageBitmap: Bitmap? = null,
    val isFavorited: Boolean = false
)

enum class VideoCameraMotion(val titleArabic: String, val icon: String) {
    DRONE_FLYBY("تحليق درون جوي", "🛸"),
    CINEMATIC_PAN("تحريك سينمائي جانبي", "🎥"),
    SLOW_ZOOM("تقريب درامي بطيء", "🔍"),
    ORBITAL_360("دوران بانورامي 360°", "🔄"),
    HYPERLAPSE("تسريع زمني تايم لابس", "⚡")
}

data class GeneratedVideoItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val prompt: String,
    val motion: VideoCameraMotion,
    val resolution: String = "1080p FHD",
    val durationSeconds: Int = 6,
    val fps: Int = 30,
    val modelName: String = "Veo 3.1 Fast",
    val timestamp: Long = System.currentTimeMillis(),
    val previewDrawableRes: Int,
    val videoTitleArabic: String
)

data class PromptIdea(
    val id: String,
    val categoryArabic: String,
    val titleArabic: String,
    val promptArabic: String,
    val iconEmoji: String,
    val suggestedModel: AiModelType = AiModelType.GEMINI_FLASH_3_5
)
