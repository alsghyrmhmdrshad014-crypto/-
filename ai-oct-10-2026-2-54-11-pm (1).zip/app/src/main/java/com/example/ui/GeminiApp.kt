package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.SessionsDrawerContent
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

enum class AppNavTab(
    val titleArabic: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    CHAT("المحادثة", Icons.AutoMirrored.Filled.Chat, Icons.AutoMirrored.Outlined.Chat),
    IMAGES("الصور", Icons.Filled.Palette, Icons.Outlined.Palette),
    VIDEOS("الفيديو", Icons.Filled.Videocam, Icons.Outlined.Videocam),
    PROMPTS("المكتبة", Icons.Filled.Bookmark, Icons.Outlined.BookmarkBorder),
    SETTINGS("الإعدادات", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun GeminiApp(
    viewModel: GeminiViewModel = viewModel()
) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    var currentTab by remember { mutableStateOf(AppNavTab.CHAT) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    val sessions by viewModel.sessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()

    GeminiTheme(darkTheme = isDarkTheme) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                SessionsDrawerContent(
                    sessions = sessions,
                    currentSessionId = currentSessionId,
                    onSelectSession = { sessionId ->
                        viewModel.switchSession(sessionId)
                        coroutineScope.launch { drawerState.close() }
                        currentTab = AppNavTab.CHAT
                    },
                    onNewChatClick = {
                        viewModel.createNewSession()
                        coroutineScope.launch { drawerState.close() }
                        currentTab = AppNavTab.CHAT
                    },
                    onDeleteSession = { sessionId ->
                        viewModel.deleteSession(sessionId)
                    }
                )
            }
        ) {
            Scaffold(
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 6.dp
                    ) {
                        for (tab in AppNavTab.entries) {
                            val isSelected = tab == currentTab
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { currentTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = tab.titleArabic,
                                        tint = if (isSelected) GeminiBlue else TextGrayMuted
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.titleArabic,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isSelected) GeminiBlue else TextGrayMuted
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    indicatorColor = GeminiBlue.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.name}")
                            )
                        }
                    }
                }
            ) { paddingValues ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    AnimatedContent(
                        targetState = currentTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "tab_transition"
                    ) { tab ->
                        when (tab) {
                            AppNavTab.CHAT -> ChatScreen(
                                viewModel = viewModel,
                                onOpenDrawer = {
                                    coroutineScope.launch { drawerState.open() }
                                }
                            )
                            AppNavTab.IMAGES -> ImageStudioScreen(viewModel = viewModel)
                            AppNavTab.VIDEOS -> VideoStudioScreen(viewModel = viewModel)
                            AppNavTab.PROMPTS -> PromptLibraryScreen(
                                viewModel = viewModel,
                                onUsePromptInChat = { promptText ->
                                    viewModel.updateMessageInput(promptText)
                                    currentTab = AppNavTab.CHAT
                                }
                            )
                            AppNavTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}
