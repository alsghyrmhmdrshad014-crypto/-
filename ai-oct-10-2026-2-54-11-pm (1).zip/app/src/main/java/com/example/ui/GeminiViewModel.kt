package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.AiKnowledgeEngine
import com.example.data.GeminiApiClient
import com.example.data.local.ChatRepository
import com.example.data.local.GeminiDatabase
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

class GeminiViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val context: Context get() = getApplication<Application>().applicationContext

    // Local Room Database Repository
    private val database = GeminiDatabase.getInstance(application)
    private val repository = ChatRepository(database.chatDao())

    // TTS Engine
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    // Chat Sessions
    private val _sessions = MutableStateFlow<List<ChatSession>>(emptyList())
    val sessions: StateFlow<List<ChatSession>> = _sessions.asStateFlow()

    private val _currentSessionId = MutableStateFlow<String>("")
    val currentSessionId: StateFlow<String> = _currentSessionId.asStateFlow()

    private val _currentMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val currentMessages: StateFlow<List<ChatMessage>> = _currentMessages.asStateFlow()

    private var messagesObservationJob: Job? = null

    // Model & Input
    private val _selectedModel = MutableStateFlow(AiModelType.GEMINI_FLASH_3_5)
    val selectedModel: StateFlow<AiModelType> = _selectedModel.asStateFlow()

    private val _messageInput = MutableStateFlow("")
    val messageInput: StateFlow<String> = _messageInput.asStateFlow()

    private val _attachedImage = MutableStateFlow<Bitmap?>(null)
    val attachedImage: StateFlow<Bitmap?> = _attachedImage.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    // Image Studio States
    private val _imagePrompt = MutableStateFlow("")
    val imagePrompt: StateFlow<String> = _imagePrompt.asStateFlow()

    private val _selectedImageStyle = MutableStateFlow(ImageArtStyle.CYBERPUNK)
    val selectedImageStyle: StateFlow<ImageArtStyle> = _selectedImageStyle.asStateFlow()

    private val _selectedAspectRatio = MutableStateFlow(ImageAspectRatio.SQUARE)
    val selectedAspectRatio: StateFlow<ImageAspectRatio> = _selectedAspectRatio.asStateFlow()

    private val _isGeneratingImage = MutableStateFlow(false)
    val isGeneratingImage: StateFlow<Boolean> = _isGeneratingImage.asStateFlow()

    private val _generatedImages = MutableStateFlow<List<GeneratedImageItem>>(emptyList())
    val generatedImages: StateFlow<List<GeneratedImageItem>> = _generatedImages.asStateFlow()

    // Video Studio States
    private val _videoPrompt = MutableStateFlow("")
    val videoPrompt: StateFlow<String> = _videoPrompt.asStateFlow()

    private val _selectedCameraMotion = MutableStateFlow(VideoCameraMotion.DRONE_FLYBY)
    val selectedCameraMotion: StateFlow<VideoCameraMotion> = _selectedCameraMotion.asStateFlow()

    private val _videoResolution = MutableStateFlow("1080p FHD")
    val videoResolution: StateFlow<String> = _videoResolution.asStateFlow()

    private val _isGeneratingVideo = MutableStateFlow(false)
    val isGeneratingVideo: StateFlow<Boolean> = _isGeneratingVideo.asStateFlow()

    private val _generatedVideos = MutableStateFlow<List<GeneratedVideoItem>>(emptyList())
    val generatedVideos: StateFlow<List<GeneratedVideoItem>> = _generatedVideos.asStateFlow()

    private val _activePlayingVideo = MutableStateFlow<GeneratedVideoItem?>(null)
    val activePlayingVideo: StateFlow<GeneratedVideoItem?> = _activePlayingVideo.asStateFlow()

    private val _isVideoPlaying = MutableStateFlow(false)
    val isVideoPlaying: StateFlow<Boolean> = _isVideoPlaying.asStateFlow()

    private val _videoProgress = MutableStateFlow(0f)
    val videoProgress: StateFlow<Float> = _videoProgress.asStateFlow()

    private var videoPlaybackJob: Job? = null

    // App Preferences
    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _promptCategoryFilter = MutableStateFlow("الكل")
    val promptCategoryFilter: StateFlow<String> = _promptCategoryFilter.asStateFlow()

    init {
        initTts()
        initInitialData()
        observeSessionsFromDatabase()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e("GeminiViewModel", "TTS Init failed", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.forLanguageTag("ar"))
            isTtsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!isTtsReady) {
                tts?.setLanguage(Locale.US)
                isTtsReady = true
            }
        }
    }

    private fun observeSessionsFromDatabase() {
        viewModelScope.launch {
            repository.getAllSessions().collectLatest { sessionList ->
                _sessions.value = sessionList

                if (sessionList.isEmpty()) {
                    // Seed initial welcome session in Room DB
                    val initial = repository.ensureInitialWelcomeSession()
                    _currentSessionId.value = initial.id
                    observeMessagesForSession(initial.id)
                } else if (_currentSessionId.value.isBlank() || sessionList.none { it.id == _currentSessionId.value }) {
                    val firstSession = sessionList.first()
                    _currentSessionId.value = firstSession.id
                    _selectedModel.value = firstSession.modelType
                    observeMessagesForSession(firstSession.id)
                }
            }
        }
    }

    private fun observeMessagesForSession(sessionId: String) {
        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            repository.getMessagesForSession(sessionId).collectLatest { msgs ->
                // Only update if not currently streaming a local message
                if (!_isGenerating.value) {
                    _currentMessages.value = msgs
                }
            }
        }
    }

    private fun initInitialData() {
        // Initial sample generated images
        _generatedImages.value = listOf(
            GeneratedImageItem(
                prompt = "مدينة عربية مستقبلية مع أضواء نيون سايبربانك ومآذن شاهقة بتقنية الهولوغرام",
                style = ImageArtStyle.CYBERPUNK,
                aspectRatio = ImageAspectRatio.LANDSCAPE,
                localDrawableRes = R.drawable.ai_image_creation
            ),
            GeneratedImageItem(
                prompt = "شعار النجم اللامع الذكي لـ Gemini AI بتدرج لوني أزرق وأرجواني سماوي",
                style = ImageArtStyle.RENDER_3D,
                aspectRatio = ImageAspectRatio.SQUARE,
                localDrawableRes = R.drawable.ai_chat_icon
            )
        )

        // Initial sample generated videos
        val initialVideo = GeneratedVideoItem(
            prompt = "مشهد درون سينمائي يحلق فوق واحة متلألئة بين أبراج زجاجية مستقبلية بتقنية 4K",
            motion = VideoCameraMotion.DRONE_FLYBY,
            resolution = "1080p FHD",
            previewDrawableRes = R.drawable.ai_video_creation,
            videoTitleArabic = "تحليق درون فوق واحة المستقبل"
        )
        _generatedVideos.value = listOf(initialVideo)
        _activePlayingVideo.value = initialVideo
    }

    fun updateMessageInput(input: String) {
        _messageInput.value = input
    }

    fun setAttachedImage(bitmap: Bitmap?) {
        _attachedImage.value = bitmap
    }

    fun selectModel(model: AiModelType) {
        _selectedModel.value = model
        val currentId = _currentSessionId.value
        if (currentId.isNotBlank()) {
            viewModelScope.launch {
                repository.updateSessionModel(currentId, model)
            }
        }
    }

    fun createNewSession() {
        viewModelScope.launch {
            val newSession = ChatSession(
                title = "محادثة جديدة",
                modelType = _selectedModel.value
            )
            repository.insertSession(newSession)
            _currentSessionId.value = newSession.id
            _currentMessages.value = emptyList()
            observeMessagesForSession(newSession.id)
        }
    }

    fun switchSession(sessionId: String) {
        val session = _sessions.value.find { it.id == sessionId } ?: return
        _currentSessionId.value = session.id
        _selectedModel.value = session.modelType
        observeMessagesForSession(session.id)
    }

    fun deleteSession(sessionId: String) {
        viewModelScope.launch {
            repository.deleteSession(sessionId)
            val remaining = _sessions.value.filter { it.id != sessionId }
            if (remaining.isEmpty()) {
                createNewSession()
            } else if (_currentSessionId.value == sessionId) {
                switchSession(remaining.first().id)
            }
        }
    }

    fun sendMessage(customPrompt: String? = null) {
        val prompt = (customPrompt ?: _messageInput.value).trim()
        if (prompt.isBlank() && _attachedImage.value == null) return

        val attached = _attachedImage.value
        _messageInput.value = ""
        _attachedImage.value = null

        val userMessage = ChatMessage(
            role = MessageRole.USER,
            text = prompt,
            attachedImage = attached
        )

        val currentSessionId = _currentSessionId.value
        if (currentSessionId.isBlank()) return

        // Save user message to Room DB
        viewModelScope.launch {
            repository.insertMessage(currentSessionId, userMessage)

            // Auto-update session title if it was "محادثة جديدة"
            val currentSession = _sessions.value.find { it.id == currentSessionId }
            if (currentSession != null && (currentSession.title == "محادثة جديدة" || _currentMessages.value.isEmpty())) {
                val newTitle = if (prompt.length > 25) prompt.take(25) + "..." else prompt
                repository.updateSessionTitle(currentSessionId, newTitle)
            }
        }

        // Add to local UI flow
        val updatedList = _currentMessages.value.toMutableList()
        updatedList.add(userMessage)
        _currentMessages.value = updatedList

        executeAiGeneration(currentSessionId, prompt, attached)
    }

    private fun executeAiGeneration(sessionId: String, prompt: String, bitmap: Bitmap?) {
        _isGenerating.value = true
        val model = _selectedModel.value

        viewModelScope.launch {
            // Prepare history
            val history = _currentMessages.value
                .dropLast(1)
                .takeLast(6)
                .map { (if (it.role == MessageRole.USER) "user" else "assistant") to it.text }

            // Try live Gemini API first
            var responseText = ""
            var isFromApi = false

            if (GeminiApiClient.isApiKeyConfigured()) {
                val apiResult = GeminiApiClient.generateTextResponse(
                    prompt = prompt,
                    modelType = model,
                    attachedBitmap = bitmap,
                    conversationHistory = history
                )
                if (apiResult.isSuccess) {
                    responseText = apiResult.getOrNull() ?: ""
                    isFromApi = true
                }
            }

            // If API didn't return text, use Smart AI Engine
            if (responseText.isBlank()) {
                responseText = AiKnowledgeEngine.generateSmartResponse(prompt, model)
            }

            // Simulate typing streaming animation for ChatGPT/Gemini realism
            val placeholderMessage = ChatMessage(
                role = MessageRole.ASSISTANT,
                text = "",
                isStreaming = true,
                modelName = if (isFromApi) model.displayNameEnglish else "${model.displayNameArabic} (محرك متكامل)"
            )

            val withPlaceholder = _currentMessages.value.toMutableList().apply { add(placeholderMessage) }
            _currentMessages.value = withPlaceholder

            // Stream text chunks
            val words = responseText.split(" ")
            val sb = StringBuilder()
            val chunkSize = 3
            for (i in words.indices step chunkSize) {
                delay(35)
                val chunk = words.subList(i, minOf(i + chunkSize, words.size)).joinToString(" ")
                if (sb.isNotEmpty()) sb.append(" ")
                sb.append(chunk)

                val streamingMessage = placeholderMessage.copy(
                    text = sb.toString(),
                    isStreaming = true
                )
                val current = _currentMessages.value.toMutableList()
                if (current.isNotEmpty()) {
                    current[current.lastIndex] = streamingMessage
                    _currentMessages.value = current
                }
            }

            // Finalize message and save permanently into Room Database
            val finalMessage = placeholderMessage.copy(
                text = responseText,
                isStreaming = false
            )

            repository.insertMessage(sessionId, finalMessage)

            val finalList = _currentMessages.value.toMutableList()
            if (finalList.isNotEmpty()) {
                finalList[finalList.lastIndex] = finalMessage
                _currentMessages.value = finalList
            }

            _isGenerating.value = false
        }
    }

    fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Gemini AI", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "تم نسخ النص إلى الحافظة", Toast.LENGTH_SHORT).show()
    }

    fun shareText(text: String, chooserTitle: String = "مشاركة الرد عبر") {
        if (text.isBlank()) return
        try {
            val sendIntent = android.content.Intent().apply {
                action = android.content.Intent.ACTION_SEND
                putExtra(android.content.Intent.EXTRA_TEXT, text)
                type = "text/plain"
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val shareIntent = android.content.Intent.createChooser(sendIntent, chooserTitle).apply {
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            Log.e("GeminiViewModel", "Failed to share text", e)
            Toast.makeText(context, "تعذر فتح نافذة المشاركة", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareCurrentSession() {
        val messages = _currentMessages.value
        if (messages.isEmpty()) {
            Toast.makeText(context, "لا توجد رسائل لمشاركتها حالياً", Toast.LENGTH_SHORT).show()
            return
        }

        val currentSession = _sessions.value.find { it.id == _currentSessionId.value }
        val sessionTitle = currentSession?.title ?: "محادثة Gemini AI"

        val sb = StringBuilder()
        sb.appendLine("✨ $sessionTitle ✨")
        sb.appendLine("──────────────────")
        for (msg in messages) {
            val sender = if (msg.role == MessageRole.USER) "👤 أنت" else "🤖 ${msg.modelName}"
            sb.appendLine("$sender:")
            sb.appendLine(msg.text)
            sb.appendLine()
        }
        sb.appendLine("──────────────────")
        sb.appendLine("تمت المشاركة عبر تطبيق Gemini AI 🚀")

        shareText(sb.toString().trim(), chooserTitle = "مشاركة نص المحادثة عبر")
    }

    fun speakText(text: String) {
        if (!isTtsReady || tts == null) {
            Toast.makeText(context, "محرك النطق غير متاح حالياً", Toast.LENGTH_SHORT).show()
            return
        }

        if (_isSpeaking.value) {
            tts?.stop()
            _isSpeaking.value = false
        } else {
            val cleanText = text.replace(Regex("[*#>`]"), "")
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "gemini_tts")
            _isSpeaking.value = true
        }
    }

    fun toggleLikeMessage(messageId: String, isLike: Boolean) {
        val currentMsg = _currentMessages.value.find { it.id == messageId }
        val newLiked = if (currentMsg?.isLiked == isLike) null else isLike

        _currentMessages.update { list ->
            list.map {
                if (it.id == messageId) it.copy(isLiked = newLiked) else it
            }
        }

        viewModelScope.launch {
            repository.updateMessageLikeStatus(messageId, newLiked)
        }
    }

    // --- Image Generation Studio ---
    fun updateImagePrompt(prompt: String) {
        _imagePrompt.value = prompt
    }

    fun selectImageStyle(style: ImageArtStyle) {
        _selectedImageStyle.value = style
    }

    fun selectAspectRatio(ratio: ImageAspectRatio) {
        _selectedAspectRatio.value = ratio
    }

    fun generateImage() {
        val prompt = _imagePrompt.value.trim()
        if (prompt.isBlank()) return

        _isGeneratingImage.value = true
        viewModelScope.launch {
            delay(1800)
            val newItem = GeneratedImageItem(
                prompt = prompt,
                style = _selectedImageStyle.value,
                aspectRatio = _selectedAspectRatio.value,
                localDrawableRes = if (_generatedImages.value.size % 2 == 0) R.drawable.ai_image_creation else R.drawable.ai_video_creation
            )
            _generatedImages.update { listOf(newItem) + it }
            _isGeneratingImage.value = false
            Toast.makeText(context, "تم توليد الصورة بنجاح! ✨", Toast.LENGTH_SHORT).show()
        }
    }

    // --- Video Generation Studio (Veo AI) ---
    fun updateVideoPrompt(prompt: String) {
        _videoPrompt.value = prompt
    }

    fun selectCameraMotion(motion: VideoCameraMotion) {
        _selectedCameraMotion.value = motion
    }

    fun selectResolution(res: String) {
        _videoResolution.value = res
    }

    fun generateVideo() {
        val prompt = _videoPrompt.value.trim()
        if (prompt.isBlank()) return

        _isGeneratingVideo.value = true
        viewModelScope.launch {
            delay(2400)
            val newVideo = GeneratedVideoItem(
                prompt = prompt,
                motion = _selectedCameraMotion.value,
                resolution = _videoResolution.value,
                previewDrawableRes = R.drawable.ai_video_creation,
                videoTitleArabic = if (prompt.length > 25) prompt.take(25) + "..." else prompt
            )
            _generatedVideos.update { listOf(newVideo) + it }
            _activePlayingVideo.value = newVideo
            _isGeneratingVideo.value = false
            startVideoPlayback()
            Toast.makeText(context, "تم إنتاج المشهد السينمائي عبر Veo 🎬", Toast.LENGTH_SHORT).show()
        }
    }

    fun playVideo(video: GeneratedVideoItem) {
        _activePlayingVideo.value = video
        startVideoPlayback()
    }

    fun togglePlayPauseVideo() {
        if (_isVideoPlaying.value) {
            pauseVideoPlayback()
        } else {
            startVideoPlayback()
        }
    }

    private fun startVideoPlayback() {
        videoPlaybackJob?.cancel()
        _isVideoPlaying.value = true
        videoPlaybackJob = viewModelScope.launch {
            while (_isVideoPlaying.value) {
                delay(100)
                val current = _videoProgress.value + 0.025f
                if (current >= 1f) {
                    _videoProgress.value = 0f
                } else {
                    _videoProgress.value = current
                }
            }
        }
    }

    private fun pauseVideoPlayback() {
        _isVideoPlaying.value = false
        videoPlaybackJob?.cancel()
    }

    fun setVideoProgress(progress: Float) {
        _videoProgress.value = progress.coerceIn(0f, 1f)
    }

    // --- UI Filters & Themes ---
    fun setPromptCategory(cat: String) {
        _promptCategoryFilter.value = cat
    }

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
        videoPlaybackJob?.cancel()
        messagesObservationJob?.cancel()
    }
}
