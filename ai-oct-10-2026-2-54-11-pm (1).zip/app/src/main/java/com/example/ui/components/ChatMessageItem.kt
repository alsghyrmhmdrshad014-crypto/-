package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatMessage
import com.example.model.MessageRole
import com.example.ui.theme.*

@Composable
fun ChatMessageItem(
    message: ChatMessage,
    onCopyClick: (String) -> Unit,
    onSpeakClick: (String) -> Unit,
    onShareClick: (String) -> Unit,
    onLikeClick: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == MessageRole.USER

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp, horizontal = 12.dp)
            .testTag("chat_message_${message.id}"),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            // AI Assistant Avatar
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(GeminiBlue, GeminiPurple, GeminiCyan)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Gemini AI",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.widthIn(max = 320.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            if (!isUser) {
                // Model Name Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 4.dp)
                ) {
                    Text(
                        text = message.modelName,
                        style = MaterialTheme.typography.labelSmall,
                        color = GeminiCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (message.isStreaming) {
                        Spacer(modifier = Modifier.width(6.dp))
                        PulsingDot()
                    }
                }
            }

            // Attached user image if any
            if (message.attachedImage != null) {
                Image(
                    bitmap = message.attachedImage.asImageBitmap(),
                    contentDescription = "Attached Image",
                    modifier = Modifier
                        .padding(bottom = 6.dp)
                        .size(160.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, GeminiBlue.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            // Message Bubble
            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                color = if (isUser) GeminiBlue else MaterialTheme.colorScheme.surfaceVariant,
                tonalElevation = if (isUser) 0.dp else 2.dp,
                border = if (!isUser) androidx.compose.foundation.BorderStroke(1.dp, GeminiCardBorder) else null
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    FormattedMessageContent(
                        text = message.text,
                        isUser = isUser,
                        onCopyCode = onCopyClick
                    )
                }
            }

            // Assistant Toolbar (Copy, Read Aloud, Thumbs Up/Down)
            if (!isUser && !message.isStreaming && message.text.isNotBlank()) {
                Row(
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .height(32.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = { onCopyClick(message.text) },
                        modifier = Modifier.size(28.dp).testTag("copy_message_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ContentCopy,
                            contentDescription = "Copy",
                            tint = TextGrayMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { onSpeakClick(message.text) },
                        modifier = Modifier.size(28.dp).testTag("speak_message_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Speak",
                            tint = TextGrayMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { onShareClick(message.text) },
                        modifier = Modifier.size(28.dp).testTag("share_message_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Share,
                            contentDescription = "Share",
                            tint = TextGrayMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { onLikeClick(message.id, true) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (message.isLiked == true) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
                            contentDescription = "Like",
                            tint = if (message.isLiked == true) GeminiBlue else TextGrayMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { onLikeClick(message.id, false) },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (message.isLiked == false) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
                            contentDescription = "Dislike",
                            tint = if (message.isLiked == false) ErrorRose else TextGrayMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "User",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun FormattedMessageContent(
    text: String,
    isUser: Boolean,
    onCopyCode: (String) -> Unit
) {
    if (isUser) {
        Text(
            text = text,
            color = Color.White,
            style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp, lineHeight = 22.sp)
        )
        return
    }

    // Split text into regular sections and markdown code blocks ```
    val blocks = remember(text) { parseMarkdownBlocks(text) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (block in blocks) {
            when (block) {
                is Block.Code -> {
                    CodeBlockView(code = block.code, language = block.lang, onCopy = { onCopyCode(block.code) })
                }
                is Block.Paragraph -> {
                    Text(
                        text = block.text,
                        color = MaterialTheme.colorScheme.onSurface,
                        style = MaterialTheme.typography.bodyMedium.copy(fontSize = 15.sp, lineHeight = 22.sp)
                    )
                }
            }
        }
    }
}

@Composable
fun CodeBlockView(
    code: String,
    language: String,
    onCopy: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(CodeBg)
            .border(1.dp, CodeBorder, RoundedCornerShape(8.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF161B22))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.ifBlank { "code" },
                style = MaterialTheme.typography.labelSmall,
                color = TextGrayMuted,
                fontFamily = FontFamily.Monospace
            )
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { onCopy() }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy code",
                    tint = TextGrayMuted,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "نسخ",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextGrayMuted
                )
            }
        }
        Text(
            text = code.trim(),
            modifier = Modifier.padding(12.dp),
            style = MaterialTheme.typography.bodySmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 18.sp
            ),
            color = CodeString
        )
    }
}

@Composable
fun PulsingDot() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Box(
        modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(GeminiCyan.copy(alpha = alpha))
    )
}

sealed class Block {
    data class Paragraph(val text: String) : Block()
    data class Code(val code: String, val lang: String) : Block()
}

fun parseMarkdownBlocks(rawText: String): List<Block> {
    val result = mutableListOf<Block>()
    val lines = rawText.lines()
    var inCodeBlock = false
    var currentLang = ""
    val currentCode = StringBuilder()
    val currentParagraph = StringBuilder()

    for (line in lines) {
        if (line.trim().startsWith("```")) {
            if (inCodeBlock) {
                // End of code block
                result.add(Block.Code(currentCode.toString(), currentLang))
                currentCode.clear()
                inCodeBlock = false
            } else {
                // Flush paragraph
                if (currentParagraph.isNotBlank()) {
                    result.add(Block.Paragraph(currentParagraph.toString().trim()))
                    currentParagraph.clear()
                }
                currentLang = line.trim().removePrefix("```").trim()
                inCodeBlock = true
            }
        } else {
            if (inCodeBlock) {
                currentCode.appendLine(line)
            } else {
                currentParagraph.appendLine(line)
            }
        }
    }

    if (inCodeBlock && currentCode.isNotBlank()) {
        result.add(Block.Code(currentCode.toString(), currentLang))
    } else if (currentParagraph.isNotBlank()) {
        result.add(Block.Paragraph(currentParagraph.toString().trim()))
    }

    return if (result.isEmpty()) listOf(Block.Paragraph(rawText)) else result
}
