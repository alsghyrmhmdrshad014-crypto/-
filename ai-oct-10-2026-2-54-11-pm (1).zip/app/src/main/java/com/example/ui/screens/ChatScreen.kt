package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.PromptPresets
import com.example.ui.GeminiViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: GeminiViewModel,
    onOpenDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.currentMessages.collectAsState()
    val messageInput by viewModel.messageInput.collectAsState()
    val attachedImage by viewModel.attachedImage.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()

    var showModelSheet by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    // Auto-scroll when messages update
    LaunchedEffect(messages.size, messages.lastOrNull()?.text?.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { showModelSheet = true }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(GeminiBlue, GeminiPurple))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Sparkle",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Gemini AI",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = TextGrayMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = selectedModel.displayNameArabic,
                                style = MaterialTheme.typography.labelSmall,
                                color = GeminiCyan
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier.testTag("open_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Menu / History",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.shareCurrentSession() },
                        modifier = Modifier.testTag("appbar_share_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Share,
                            contentDescription = "Share Chat",
                            tint = GeminiCyan
                        )
                    }
                    IconButton(
                        onClick = { viewModel.createNewSession() },
                        modifier = Modifier.testTag("appbar_new_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "New Chat",
                            tint = GeminiBlue
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            ChatInputField(
                inputText = messageInput,
                onInputChange = { viewModel.updateMessageInput(it) },
                onSendClick = { viewModel.sendMessage() },
                attachedImage = attachedImage,
                onImageAttached = { viewModel.setAttachedImage(it) },
                selectedModel = selectedModel,
                onModelClick = { showModelSheet = true },
                isGenerating = isGenerating
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (messages.isEmpty()) {
                // Empty State / Welcome Screen with Quick Prompts
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(GeminiBlue, GeminiPurple, GeminiCyan))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Gemini Star",
                            tint = Color.White,
                            modifier = Modifier.size(40.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "بماذا يمكنني مساعدتك اليوم؟",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "اطرح أسئلة برمجية، اطلب كتابة إبداعية، أو اطلب توليد صور وفيديوهات",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextGrayMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp, bottom = 28.dp)
                    )

                    StarterPromptCards(
                        prompts = PromptPresets.starterPrompts,
                        onPromptClick = { prompt ->
                            viewModel.sendMessage(prompt)
                        }
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatMessageItem(
                            message = msg,
                            onCopyClick = { viewModel.copyToClipboard(it) },
                            onSpeakClick = { viewModel.speakText(it) },
                            onShareClick = { viewModel.shareText(it, "مشاركة الرد عبر") },
                            onLikeClick = { id, like -> viewModel.toggleLikeMessage(id, like) }
                        )
                    }

                    if (isGenerating && messages.lastOrNull()?.isStreaming != true) {
                        item {
                            Row(
                                modifier = Modifier
                                    .padding(start = 16.dp, top = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = GeminiBlue,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Gemini يفكر في الإجابة...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextGrayMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        if (showModelSheet) {
            ModelSelectorSheet(
                selectedModel = selectedModel,
                onModelSelected = { viewModel.selectModel(it) },
                onDismiss = { showModelSheet = false }
            )
        }
    }
}
