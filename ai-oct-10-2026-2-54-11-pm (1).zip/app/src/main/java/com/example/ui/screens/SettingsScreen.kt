package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GeminiApiClient
import com.example.ui.GeminiViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: GeminiViewModel,
    modifier: Modifier = Modifier
) {
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val isApiConfigured = remember { GeminiApiClient.isApiKeyConfigured() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(GeminiPurple, GeminiBlue))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "إعدادات التطبيق والمحرك الذكي",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // API Connection Status Card
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isApiConfigured) SuccessEmerald else WarningAmber
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(if (isApiConfigured) SuccessEmerald.copy(alpha = 0.2f) else WarningAmber.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isApiConfigured) Icons.Default.CheckCircle else Icons.Default.Info,
                                    contentDescription = null,
                                    tint = if (isApiConfigured) SuccessEmerald else WarningAmber
                                )
                            }

                            Column {
                                Text(
                                    text = if (isApiConfigured) "متصل بـ Gemini Cloud API" else "محرك الذكاء المدمج الفوري نشط",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = if (isApiConfigured) "تم تفعيل مفتاح الـ API بنجاح" else "يعمل بنظام الاستجابة الذكية المدمج بدقة عالية",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextGrayMuted
                                )
                            }
                        }

                        if (!isApiConfigured) {
                            Text(
                                text = "💡 لربط مفتاح API رسمي من Google AI Studio، افتح لوحة الأسرار (Secrets Panel) وأضف GEMINI_API_KEY.",
                                style = MaterialTheme.typography.bodySmall,
                                color = GeminiCyan,
                                modifier = Modifier.padding(top = 10.dp)
                            )
                        }
                    }
                }
            }

            // Appearance & Theming
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeminiCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "المظهر والشاشات",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isDarkTheme) Icons.Default.DarkMode else Icons.Default.LightMode,
                                    contentDescription = null,
                                    tint = GeminiBlue
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "الوضع الليلي الكوني (Dark Mode)",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = if (isDarkTheme) "الوضع الليلي نشط" else "الوضع النهاري نشط",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextGrayMuted
                                    )
                                }
                            }

                            Switch(
                                checked = isDarkTheme,
                                onCheckedChange = { viewModel.toggleTheme() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = GeminiBlue
                                ),
                                modifier = Modifier.testTag("theme_toggle_switch")
                            )
                        }
                    }
                }
            }

            // Models & Features Info
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeminiCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "النماذج المدعومة",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(bottom = 10.dp)
                        )

                        val supportedList = listOf(
                            "⚡ Gemini 3.5 Flash: سرعة فائقة وإجابات يومية دقيقة",
                            "🧠 Gemini 3.1 Pro: تفكير متعمق واستدلال وبرمجة متقدمة",
                            "🎨 Gemini 2.5 Flash Image: رسم وتوليد صور إبداعية",
                            "🎬 Veo 3.1 AI: إنتاج مقاطع فيديو سينمائية متحركة",
                            "🎙️ Android TTS: تحويل النصوص المكتوبة إلى نطق صوتي فوري"
                        )

                        for (item in supportedList) {
                            Text(
                                text = item,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextGrayLight,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // About App
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeminiCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "عن التطبيق والخصوصية",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "تطبيق Gemini AI يوفر لك أقوى تجربة محادثة ذكية وتوليد للوسائط المتعددة (نصوص، صور، وفيديوهات) مع واجهة عربية أصيلة وتصميم حديث يتوافق مع أعلى معايير الخصوصية والأداء.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextGrayMuted,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                        Text(
                            text = "الإصدار 1.0 • صُمم خصيصاً لتجربة مستخدم عربية وعالمية فائقة الجودة",
                            style = MaterialTheme.typography.labelSmall,
                            color = GeminiCyan,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }
                }
            }
        }
    }
}
