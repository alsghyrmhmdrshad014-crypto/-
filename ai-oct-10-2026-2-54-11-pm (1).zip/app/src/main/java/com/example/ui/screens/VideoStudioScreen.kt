package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GeneratedVideoItem
import com.example.model.VideoCameraMotion
import com.example.ui.GeminiViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoStudioScreen(
    viewModel: GeminiViewModel,
    modifier: Modifier = Modifier
) {
    val prompt by viewModel.videoPrompt.collectAsState()
    val selectedMotion by viewModel.selectedCameraMotion.collectAsState()
    val selectedResolution by viewModel.videoResolution.collectAsState()
    val isGenerating by viewModel.isGeneratingVideo.collectAsState()
    val generatedVideos by viewModel.generatedVideos.collectAsState()
    val activeVideo by viewModel.activePlayingVideo.collectAsState()
    val isPlaying by viewModel.isVideoPlaying.collectAsState()
    val progress by viewModel.videoProgress.collectAsState()

    val quickVideoPrompts = listOf(
        "مشهد درون سينمائي يحلق فوق واحة متلألئة بين كثبان رملية ذهبية",
        "تسريع زمني تايم لابس لحركة النجوم والمجرات فوق أبراج دبي المستقبلية",
        "كاميرا تتبع سريعة لسيارة كهربائية مضيئة على طريق ساحلي",
        "دوران بانورامي 360° حول روبوت ذكي يتفاعل مع فراشات ضوئية"
    )

    // Motion animation effect on video frame when playing
    val infiniteTransition = rememberInfiniteTransition(label = "camera_motion")
    val panOffset by infiniteTransition.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pan"
    )
    val zoomScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = EaseInOutQuad),
            repeatMode = RepeatMode.Reverse
        ),
        label = "zoom"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(GeminiBlue, GeminiCyan))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Videocam,
                                contentDescription = "Video Studio",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "استوديو الفيديو (Veo AI)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Veo 3.1 Fast Generate Preview",
                                style = MaterialTheme.typography.labelSmall,
                                color = GeminiCyan
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Interactive Video Player Card
            item {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeminiCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        // Video Screen with simulation
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(Color.Black)
                        ) {
                            val active = activeVideo
                            if (active != null) {
                                Image(
                                    painter = painterResource(id = active.previewDrawableRes),
                                    contentDescription = active.prompt,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                        .graphicsLayer {
                                            if (isPlaying) {
                                                translationX = panOffset * 2f
                                                scaleX = zoomScale
                                                scaleY = zoomScale
                                            }
                                        },
                                    contentScale = ContentScale.Crop
                                )
                            }

                            // Dark overlay with controls
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Black.copy(alpha = 0.5f),
                                                Color.Transparent,
                                                Color.Black.copy(alpha = 0.8f)
                                            )
                                        )
                                    )
                            )

                            // Top video badges
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = GeminiBlue.copy(alpha = 0.85f)
                                ) {
                                    Text(
                                        text = "Veo 3.1 AI • 60 FPS",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color.Black.copy(alpha = 0.7f)
                                ) {
                                    Text(
                                        text = activeVideo?.resolution ?: "1080p FHD",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GeminiCyan,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            // Center Play / Pause Floating Button
                            Box(
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .border(2.dp, GeminiCyan, CircleShape)
                                    .clickable { viewModel.togglePlayPauseVideo() }
                                    .testTag("play_pause_video_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            // Bottom Scrubber Bar & Timestamp
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    val currentSec = (progress * (activeVideo?.durationSeconds ?: 6)).toInt()
                                    Text(
                                        text = "00:0$currentSec / 00:0${activeVideo?.durationSeconds ?: 6}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White
                                    )
                                    Text(
                                        text = activeVideo?.motion?.titleArabic ?: "تحليق درون جوي",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GeminiCyan
                                    )
                                }

                                Slider(
                                    value = progress,
                                    onValueChange = { viewModel.setVideoProgress(it) },
                                    colors = SliderDefaults.colors(
                                        thumbColor = GeminiCyan,
                                        activeTrackColor = GeminiBlue,
                                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                    ),
                                    modifier = Modifier.height(20.dp)
                                )
                            }
                        }

                        // Video Title & Details
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = activeVideo?.videoTitleArabic ?: "مشهد سينمائي مولد بالذكاء الاصطناعي",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = activeVideo?.prompt ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextGrayMuted,
                                modifier = Modifier.padding(top = 4.dp),
                                maxLines = 2
                            )
                        }
                    }
                }
            }

            // Prompt Input Card
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GeminiCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "وصف المشهد السينمائي والحركة 🎬",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        OutlinedTextField(
                            value = prompt,
                            onValueChange = { viewModel.updateVideoPrompt(it) },
                            placeholder = {
                                Text(
                                    text = "صف المشهد، حركة الكاميرا، وسرعة الحركة بالتفصيل...",
                                    color = TextGrayMuted,
                                    fontSize = 14.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp)
                                .testTag("video_prompt_input"),
                            minLines = 3,
                            maxLines = 5,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GeminiBlue,
                                unfocusedBorderColor = GeminiCardBorder
                            )
                        )

                        // Quick video prompt inspiration
                        Text(
                            text = "أفكار مقترحة لمشاهد سينمائية:",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextGrayMuted,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(quickVideoPrompts) { quick ->
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, GeminiCardBorder),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .clickable { viewModel.updateVideoPrompt(quick) }
                                ) {
                                    Text(
                                        text = quick,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GeminiCyan,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Camera Motion Preset Selector
            item {
                Column {
                    Text(
                        text = "حركة الكاميرا والإخراج 🎥",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(VideoCameraMotion.entries) { motion ->
                            val isSelected = motion == selectedMotion
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) GeminiBlue.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) GeminiBlue else GeminiCardBorder
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { viewModel.selectCameraMotion(motion) }
                                    .testTag("motion_chip_${motion.name}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = motion.icon, fontSize = 16.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = motion.titleArabic,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) GeminiBlue else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Resolution Selector
            item {
                Column {
                    Text(
                        text = "دقة الفيديو وجودة العرض ⚙️",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    val resolutions = listOf("1080p FHD", "4K Cinema", "720p Fast")
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (res in resolutions) {
                            val isSelected = res == selectedResolution
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) GeminiCyan.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) GeminiCyan else GeminiCardBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { viewModel.selectResolution(res) }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = res,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) GeminiCyan else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Generate Video Button
            item {
                Button(
                    onClick = { viewModel.generateVideo() },
                    enabled = !isGenerating && prompt.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GeminiBlue
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("generate_video_button")
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "جاري معالجة الإطارات وإنتاج الفيديو بـ Veo...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "توليد مشهد الفيديو الآن 🎬",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // Generated Videos List
            item {
                Text(
                    text = "سجل الفيديوهات المنتجة (${generatedVideos.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(generatedVideos, key = { it.id }) { video ->
                val isCurrent = video.id == activeVideo?.id
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isCurrent) GeminiBlue.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isCurrent) GeminiBlue else GeminiCardBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { viewModel.playVideo(video) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(RoundedCornerShape(10.dp))
                        ) {
                            Image(
                                painter = painterResource(id = video.previewDrawableRes),
                                contentDescription = video.videoTitleArabic,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayCircle,
                                    contentDescription = "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = video.videoTitleArabic,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                            Text(
                                text = "${video.motion.titleArabic} • ${video.resolution}",
                                style = MaterialTheme.typography.labelSmall,
                                color = GeminiCyan
                            )
                            Text(
                                text = video.prompt,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextGrayMuted,
                                maxLines = 1,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        IconButton(onClick = { viewModel.copyToClipboard(video.prompt) }) {
                            Icon(
                                imageVector = Icons.Outlined.ContentCopy,
                                contentDescription = "Copy Prompt",
                                tint = TextGrayMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
