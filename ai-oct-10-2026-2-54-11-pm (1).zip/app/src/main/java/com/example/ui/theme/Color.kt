package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gemini & ChatGPT Inspired Modern Palette
val GeminiDeepSpace = Color(0xFF0B0F19)
val GeminiSurface = Color(0xFF131826)
val GeminiSurfaceLight = Color(0xFF1E2538)
val GeminiCardBg = Color(0xFF1B2236)
val GeminiCardBorder = Color(0xFF28324E)

// Radiant Brand Accents (Gemini Star & ChatGPT Sparkle)
val GeminiBlue = Color(0xFF388BFD)
val GeminiCyan = Color(0xFF38D9D9)
val GeminiPurple = Color(0xFF9D65FF)
val GeminiPink = Color(0xFFF778BA)
val ChatGptTeal = Color(0xFF10A37F)

// Text Colors
val TextWhite = Color(0xFFFFFFFF)
val TextGrayLight = Color(0xFFE2E8F0)
val TextGrayMuted = Color(0xFF94A3B8)
val TextGrayDark = Color(0xFF64748B)

// Accent Status
val SuccessEmerald = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRose = Color(0xFFEF4444)

// Code Syntax Colors
val CodeBg = Color(0xFF0A0E17)
val CodeKeyword = Color(0xFFFF7B72)
val CodeString = Color(0xFFA5D6FF)
val CodeComment = Color(0xFF8B949E)
val CodeBorder = Color(0xFF30363D)
