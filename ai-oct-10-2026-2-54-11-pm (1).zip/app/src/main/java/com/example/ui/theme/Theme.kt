package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GeminiDarkColorScheme = darkColorScheme(
    primary = GeminiBlue,
    onPrimary = TextWhite,
    primaryContainer = GeminiSurfaceLight,
    onPrimaryContainer = GeminiCyan,
    secondary = GeminiPurple,
    onSecondary = TextWhite,
    secondaryContainer = GeminiCardBg,
    onSecondaryContainer = TextGrayLight,
    tertiary = ChatGptTeal,
    onTertiary = TextWhite,
    background = GeminiDeepSpace,
    onBackground = TextWhite,
    surface = GeminiSurface,
    onSurface = TextWhite,
    surfaceVariant = GeminiCardBg,
    onSurfaceVariant = TextGrayLight,
    outline = GeminiCardBorder,
    error = ErrorRose
)

private val GeminiLightColorScheme = lightColorScheme(
    primary = Color(0xFF1A73E8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8F0FE),
    onPrimaryContainer = Color(0xFF1967D2),
    secondary = Color(0xFF7B1FA2),
    onSecondary = Color.White,
    background = Color(0xFFF8F9FA),
    onBackground = Color(0xFF202124),
    surface = Color.White,
    onSurface = Color(0xFF202124),
    surfaceVariant = Color(0xFFF1F3F4),
    onSurfaceVariant = Color(0xFF5F6368),
    outline = Color(0xFFDADCE0),
    error = Color(0xFFD93025)
)

@Composable
fun GeminiTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) GeminiDarkColorScheme else GeminiLightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
