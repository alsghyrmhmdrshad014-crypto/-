package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.ChatRepository
import com.example.data.local.GeminiDatabase
import com.example.model.AiModelType
import com.example.model.ChatMessage
import com.example.model.ChatSession
import com.example.model.MessageRole
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: GeminiDatabase
    private lateinit var repository: ChatRepository

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, GeminiDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ChatRepository(db.chatDao())
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Gemini AI", appName)
    }

    @Test
    fun `room database stores and retrieves chat session and messages`() = runBlocking {
        val session = ChatSession(
            id = "test-session-1",
            title = "جلسة اختبار البرمجة",
            modelType = AiModelType.CODE_MASTER
        )
        repository.insertSession(session)

        val userMessage = ChatMessage(
            id = "msg-user-1",
            role = MessageRole.USER,
            text = "اكتب لي كود Room في Kotlin"
        )
        val assistantMessage = ChatMessage(
            id = "msg-ai-1",
            role = MessageRole.ASSISTANT,
            text = "إليك كود Room المتكامل..."
        )

        repository.insertMessage(session.id, userMessage)
        repository.insertMessage(session.id, assistantMessage)

        val messages = repository.getMessagesForSessionSync(session.id)
        assertEquals(2, messages.size)
        assertEquals("اكتب لي كود Room في Kotlin", messages[0].text)
        assertEquals("إليك كود Room المتكامل...", messages[1].text)
    }
}
