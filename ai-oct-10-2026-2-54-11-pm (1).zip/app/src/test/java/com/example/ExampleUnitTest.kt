package com.example

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun markdownParsing_handlesCodeBlocks() {
    val markdown = "Hello\n```kotlin\nval x = 10\n```\nWorld"
    val blocks = com.example.ui.components.parseMarkdownBlocks(markdown)
    assertEquals(3, blocks.size)
  }
}
